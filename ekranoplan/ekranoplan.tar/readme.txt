# Ekranoplan
Ekranoplan is a water vehicle newGRF, providing high speed water vehicles based primarily on USSR ground effect vehicles called ekranoplan. These not-quite-aircraft can have very high speeds and very high capacities. 1x (64 px tile width) zoom 8-bit graphics.

## Features
* Many ekranoplan. From early to futuristic fictional.
* Interesting gameplay. There are two main groups, very large, very high capacity and very fast (but slow on rivers/canals) and smaller, cheaper versions which are faster on rivers/canals.
* 2CC graphics. All ekranoplan follow a fictional two company colour plus gray colour scheme.

## Interoperability
Ekranoplan is tested for standalone use with default industries, but should work with industry NewGRFs, other ship sets, etc.. 

## Development
if you find bugs or have feature requests then please post them as Github issues on my [OpenTTD NewGRF Github repo](https://github.com/zephyris/openttd-newgrf).
